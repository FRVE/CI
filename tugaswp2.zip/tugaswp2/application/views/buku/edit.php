<selection class="content">
	<div class="row">
		<div class="col-sm-12">
			<div class="box box-danger">
				<div class="box-body">
					<form action="<?=site_url('c_buku/update') ?>" method="post" accept-charset="utf-8">

						<input type="hidden" name="id_buku" value="<?=$show->id_buku;?>">
						
						<div class="box-body">
							<div class="form-group">
								<label>Judul Buku</label>
								<input type="text" name="judul_buku" class="form-control" value="<?=$show->judul_buku?>" placeholder="masukan judul buku" required="required">
							</div>
							<div class="form-group">
								<label>Kategori</label>
								<select name="id_kategori" size="1" class="form-control">
									
								<?php
								foreach ($show_kategori as $key => $data_kategori){
									echo '<option value="'.$data_kategori->id_kategori.'">'.$data_kategori->nama_kategori.'</option>';
								}
								?>
								</select>
							</div>
							<div class="form-group">
								<label>Penggarang</label>
								<input type="text" name="penggarang" class="form-control" value="<?=$show->pengarang?>" placeholder="masukan nama penggarang" required="required">
							</div>
							<div class="form-group">
								<label>Tahun Terbit</label>
								<input type="number" class="form-control" name="thn_terbit" min="0" value="<?=$show->thn_terbit?>">
								<div class="form-group">
									<label for="exampleInputtext1">Penerbit</label>
									<input type="text" name="penerbit" class="form-control" id="exampleInputtext1" placeholder="Penerbit" value="<?=$show->penerbit;?>" required="required">
								</div>
								<div class="form-group">
								<label>ISBN</label>
								<input type="text" name="isbn" class="form-control" placeholder="0" value="<?=$show->isbn?>" required min="0">
								</div>
								<div class="form-group">
									<label>Jumlah</label>
									<input type="text" name="jumlah_buku" class="form-control" placeholder="0" value="<?=$show->jumlah_buku?>" required="0">
								</div>
								<div class="form-group">
									<label>Rak</label>
									<select name="lokasi" size="1" class="form-control">
										<option value="1">Rak 1</option>
										<option value="2">Rak 2</option>
										<option value="3">Rak 3</option>
										<option value="4">Rak 4</option>
										<option value="5">Rak 5</option>
									</select>
								</div>
							</div>
							<div class="box-footer">
								<button type="button" class="btn btn-default"> <i class="fa fa-arrow-circle-left"></i>Batal</button>
								<button type="submit" class="btn btn-primary pull-right"> <i class="fa fa-send"></i>Simpan</button>
								
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</selection>