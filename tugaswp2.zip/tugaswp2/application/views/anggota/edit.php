<section class="content">
	<div class="row">
		<div class="col-sm-12">
			<div class="box box-danger">
				<div class="box box-header">
					<h3 class="box-title">Edit Anggota</h3>
				</div>
			<input type="hidden" name="id_anggota" value="<?=$list->id_anggota;?>">
				<div class="box-body">
					<form action="<?=site_url('c_anggota/update');?>" method="post" accept-charset="UTF-8">
						<div class="box-body">
							

							<div class="form-group">
								<label>Nama Anggota</label>
								<input type="text" name="nama_anggota" class="form-control" value="<?=$list->nama_anggota?>" placeholder="" required="required">
							</div>
							<div class="form-group">
								<label>Gender</label>
								<select name="gender" size="1" class="form-control">
									<option value="<?=$list->gender?>">Laki-Laki</option>
									<option value="<?=$list->gender?>">Perempuan</option>
								</select>
							</div>
							<div class="form-group">
								<label>No Telpon</label>
								<input type="text" name="no_telp" class="form-control" value="<?=$list->no_telp?>" placeholder="" required="required">
							</div>
							<div class="form-group">
								<label>Alamat</label>
								<input type="text" name="alamat" class="form-control" value="<?=$list->alamat?>" placeholder="" required="required">
							</div>
							<div class="form-group">
								<label>Email</label>
								<input type="text" name="email" class="form-control" value="<?=$list->email?>" placeholder="" required="required">
							</div>
							<div class="form-group">
								<label>Password</label>
								<input type="password" name="password" id="pswd" class="form-control" value="<?=$list->password?>" placeholder="" required="required">
							</div>
						<div class="box-footer">
							<button type="button" class="btn btn-default">
								<i class="fa fa-arrow-circle-left"></i>
								Batal
							</button>
							<button type="submit" class="btn btn-primary pull-right">
								<i class="fa fa-send"></i>
								Submit
							</button> 
						</div>
					</form>
				</div>
			</div>		
		</div>
	</div>
</section>