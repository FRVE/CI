  <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?=base_url();?>assets/dist/img/avatar5.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Admin</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
    
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="treeview">
          <a href="<?=site_url('c_buku');?>">
            <i class="fa fa-book"></i> <span>Buku</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=site_url('c_buku');?>"><i class="fa fa-circle-o"></i>Daftar Buku</a></li>
            <li><a href="<?=site_url('c_buku/add');?>"><i class="fa fa-circle-o"></i>Tambah Buku</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="<?=site_url('c_anggota');?>">
            <i class="fa fa-user"></i> <span>Anggota</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=site_url('c_anggota');?>"><i class="fa fa-circle-o"></i>Daftar Anggota</a></li>
            <li><a href="<?=site_url('c_anggota/add');?>"><i class="fa fa-circle-o"></i>Tambah Anggota</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="<?=site_url('c_kategori');?>">
            <i class="fa fa-tasks"></i> <span>Kategori</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=site_url('c_kategori');?>"><i class="fa fa-circle-o"></i>Daftar Kategori</a></li>
            <li><a href="<?=site_url('c_kategori/add');?>"><i class="fa fa-circle-o"></i>Tambah Kategori</a></li>
          </ul>
        </li>

      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?=$title;?>
        <small><?=$sub_title;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> <?=$title;?></a></li>
        <li><a href="#"><?=$sub_title;?></a></li>
        <li class="active">Current Page</li>
      </ol>
    </section>

    <!-- Main content 
    <section class="content">
 -->