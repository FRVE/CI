<?php $this->load->view("/sub/header");?>
<?php $this->load->view("/sub/sidebar");?>
<?php $this->load->view($content);?>
<?php $this->load->view("/sub/footer");?>
