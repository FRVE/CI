<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class c_anggota extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_anggota');
	}
		public function index()
	{
		$data = 
		[
			'title' =>'Anggota|' ,
			'sub_title' => 'Daftar Anggota' ,
			'content' => 'anggota/index' ,
			'list' => $this->m_anggota ->index()->result()
		];
		$this->load->view('template/my_template', $data);
	}

	public function add()
	{
		$data = 
		[
			'title' =>'Anggota|' ,
			'sub_title' => 'Tambah anggota' ,
			'content' => 'anggota/add'
			
		];
		$this->load->view('template/my_template', $data);
	}

	public function create()
	{
		$id_anggota = $this->input->post('id_anggota');
		$nama_anggota = $this->input->post('nama_anggota');
		$gender = $this->input->post('gender');
		$no_telp = $this->input->post('no_telp');
		$alamat = $this->input->post('alamat');
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$data = array(
			'id_anggota'	=> $id_anggota,
			'nama_anggota'	=> $nama_anggota,
			'gender'		=> $gender,
			'no_telp'		=> $no_telp,
			'alamat'		=> $alamat,
			'email'			=> $email,
			'password'		=> $password,

		);

		$create = $this->m_anggota->create($data);
		if($create){
			$this->session->set_flashdata('pesan_create', true);
			redirect('c_anggota');
		}else{
			$this->session->set_flashdata('pesan_create', false);
			redirect('c_anggota');
		}
	}
	public function edit($id)
	{
	$data =
		[
		'title' => 'anggota',
		'sub_title' => 'Edit anggota',
		'content' => 'anggota/edit',
		'list' => $this->m_anggota->edit($id)->row()
		];
		$this->load->view('template/my_template', $data);	
	}
	public function update()
	{
		$id_anggota = $this->input->post('id_anggota');
		$nama_anggota = $this->input->post('nama_anggota');
		$gender = $this->input->post('gender');
		$no_telp = $this->input->post('no_telp');
		$alamat = $this->input->post('alamat');
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$data = array(
			'nama_anggota'	=> $nama_anggota,
			'gender'		=> $gender,
			'no_telp'		=> $no_telp,
			'alamat'		=> $alamat,
			'email'			=> $email,
			'password'		=> $password,
		);

		$update = $this->m_anggota->update($data, $id_anggota);
		if ($update) {
			$this->session->set_flashdata('pesan_created', true);
			redirect('c_anggota');
		}else{
			$this->session->set_flashdata('pesan_created', false);
			redirect('c_anggota');
		} 
	}
	public function delete($id)
	{
		$data = array(
				'deleted_at' => date('Y-m-d H:i:s', time())
					);
	
		$delete = $this->m_anggota->delete($data, $id);
		
		if ($delete) {
			$this->session->set_flashdata('pesan_delete', true);
			redirect('c_anggota');
		}else{
			$this->session->set_flashdata('pesan_delete', false);
			redirect('c_anggota');
		} 	
	}
}