<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class c_kategori extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('m_kategori');				
	}
	public function index(){
		$data =
		[
				'title' => 'kategori',
				'sub_title' => 'Kategori',
				'content' => 'kategori/index',
				'list' => $this->m_kategori->index()->result()
		];
		$this->load->view('template/my_template', $data);
	}

	
	public function add()
	{
		$data =
		[
			'title' => 'kategori',
			'sub_title' => 'Tambah kategori',
			'content' => 'kategori/add',
			'show_kategori' => $this->m_kategori->index()->result()
		];
		$this->load->view('template/my_template', $data);
	}
	public function create()
	{
		$nama_kategori = $this->input->post('nama_kategori');

		$data = array(
			'nama_kategori' => $nama_kategori

		);

		$create = $this->m_kategori->create($data);
		if ($create) {
			$this->session->set_flashdata('pesan_created', true);
			redirect('c_kategori');
		}else{
			$this->session->set_flashdata('pesan_created', false);
			redirect('c_kategori');
		}
	}
	public function edit($id)
	{
	$data =
		[
		'title' => 'kategori',
		'sub_title' => 'Edit kategori',
		'content' => 'kategori/edit',
		'list' => $this->m_kategori->edit($id)->row()
		];
		$this->load->view('template/my_template', $data);	
	}
	public function update()
	{
		$nama_kategori = $this->input->post('nama_kategori');

		$data = array(
			'nama_kategori' => $nama_kategori

		);

		$update = $this->m_kategori->update($data, $id_kategori);
		if ($update) {
			$this->session->set_flashdata('pesan_created', true);
			redirect('c_kategori');
		}else{
			$this->session->set_flashdata('pesan_created', false);
			redirect('c_kategori');
		} 
	}
	public function delete($id)
	{
		$data = array(
				'deleted_at' => date('Y-m-d H:i:s', time())
					);
	
		$delete = $this->m_kategori->delete($data, $id);
		
		if ($delete) {
			$this->session->set_flashdata('pesan_delete', true);
			redirect('c_kategori');
		}else{
			$this->session->set_flashdata('pesan_delete', false);
			redirect('c_kategori');
		} 	
	}


}